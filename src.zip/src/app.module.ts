import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { AuctionsModule } from './auctions/auctions.module';
import { AppController } from './app.controller';  // ✅ Importamos el controlador principal
import { AppService } from './app.service';  // ✅ Importamos el servicio principal
import { AuthMiddleware } from './middlewares/auth.middleware';

import * as admin from 'firebase-admin';
import * as fs from 'fs';
import * as path from 'path';

// ✅ Obtener la ruta correcta del archivo de credenciales
const serviceAccountPath = path.join(process.cwd(), 'config/firebase-admin.json');

let serviceAccount: any;

// ✅ Verificar si el archivo existe antes de procesarlo
if (!fs.existsSync(serviceAccountPath)) {
    console.error('🔥 ERROR: El archivo firebase-admin.json no fue encontrado.');
} else {
    try {
        serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf-8'));

        // ✅ Corregir formato de `private_key`
        if (typeof serviceAccount.private_key === 'string') {
            serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n').trim();
        }

        // ✅ Inicializar Firebase
        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount as admin.ServiceAccount),
        });

        console.log('✅ Firebase inicializado correctamente.');
    } catch (error) {
        console.error('🚨 ERROR: No se pudo leer el archivo firebase-admin.json.');
        console.error(error instanceof Error ? error.message : error);
    }
}

@Module({
    imports: [AuctionsModule],
    controllers: [AppController],  // ✅ Agregamos AppController aquí
    providers: [AppService],  // ✅ Agregamos AppService aquí
})
export class AppModule implements NestModule {
    configure(consumer: MiddlewareConsumer) {
        console.log('✅ Middleware de autenticación aplicado.');
        consumer.apply(AuthMiddleware).forRoutes('auctions', 'users', 'bids');
    }
}
