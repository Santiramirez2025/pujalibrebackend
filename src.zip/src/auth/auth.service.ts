export interface User {
  id: number;
  email: string;
  password: string;
}

import { Injectable } from '@nestjs/common';

@Injectable()
export class AuthService {
  private users: User[] = [];

  register(email: string, password: string): User {
    const newUser: User = { id: Date.now(), email, password };
    this.users.push(newUser);
    return newUser;
  }
}

export default AuthService;
