import { Controller, Get } from '@nestjs/common';

@Controller('api')  // Prefijo para todas las rutas en este controlador
export class AppController {

  @Get('status')  // Ruta para verificar el estado del servidor
  getStatus() {
    return { status: 'OK', message: 'El servidor está corriendo' };
  }

  @Get()  // Responde en '/api'
  getHello() {
    return { message: '🚀 Servidor funcionando correctamente' };
  }
}
