export class CreateAuctionDto {
  title!: string;
  startingPrice!: number;
  description?: string;
}
