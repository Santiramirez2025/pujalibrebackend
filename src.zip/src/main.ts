import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as dotenv from 'dotenv';
import { Logger } from '@nestjs/common';
import cookieParser from 'cookie-parser';  // ✅ Importación corregida
import helmet from 'helmet';  // ✅ Importación corregida
import { json, urlencoded } from 'body-parser';  // ✅ `body-parser` en vez de `express`

// Cargar variables de entorno
dotenv.config({ path: '.env' });

async function bootstrap() {
  try {
    const app = await NestFactory.create(AppModule);

    // Configurar CORS
    app.enableCors({
      origin: '*',
      methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
      credentials: true,
    });

    // Seguridad con Helmet
    app.use(helmet());

    // Middleware para manejo de cookies y JSON
    app.use(cookieParser());
    app.use(json({ limit: '10mb' }));
    app.use(urlencoded({ extended: true, limit: '10mb' }));

    // Aplicar prefijo global si no está definido
    const globalPrefix = process.env.API_PREFIX || 'api';
    app.setGlobalPrefix(globalPrefix);

    const port = process.env.PORT || 3000;
    await app.listen(port);

    Logger.log(`🚀 Servidor corriendo en: http://localhost:${port}/${globalPrefix}`, 'Bootstrap');
    Logger.log(`🔧 Modo: ${process.env.NODE_ENV || 'development'}`, 'Bootstrap');
    Logger.log(`🛠️ MercadoPago Token: ${process.env.MERCADOPAGO_ACCESS_TOKEN ? 'Cargado ✅' : 'No cargado ❌'}`, 'Bootstrap');
    Logger.log(`🎯 API URL: ${process.env.API_URL || 'http://localhost:3000'}`, 'Bootstrap');

  } catch (error) {
    Logger.error(`❌ Error al iniciar el servidor: ${(error instanceof Error) ? error.message : error}`, 'Bootstrap');
    process.exit(1);
  }
}

bootstrap();
