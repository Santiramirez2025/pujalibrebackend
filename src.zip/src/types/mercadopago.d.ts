declare module 'mercadopago' {
    const mercadopago: any;
    export default mercadopago;
  }
  